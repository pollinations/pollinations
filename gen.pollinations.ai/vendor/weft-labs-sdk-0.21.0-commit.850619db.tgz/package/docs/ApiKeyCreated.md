
# ApiKeyCreated


## Properties

Name | Type
------------ | -------------
`id` | number
`name` | string
`keyPrefix` | string
`rawKey` | string
`createdAt` | Date

## Example

```typescript
import type { ApiKeyCreated } from '@weft-labs/sdk'

// TODO: Update the object below with actual values
const example = {
  "id": null,
  "name": null,
  "keyPrefix": null,
  "rawKey": null,
  "createdAt": null,
} satisfies ApiKeyCreated

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as ApiKeyCreated
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)
