# BalanceApi

All URIs are relative to *https://weft.network*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**getBalance**](BalanceApi.md#getbalance) | **GET** /api/v1/balance | Get wallet, spending policy, and current-window spend |



## getBalance

> BalanceResponse getBalance()

Get wallet, spending policy, and current-window spend

Read-only snapshot for the buyer behind the bearer token. The response always includes a &#x60;promo&#x60; block — values are zero in v1 and fill in once the freemium promo ledger ships, without a shape change. The Base USDC balance is fetched server-side through Crossmint. If Crossmint is unreachable, the balance fields are &#x60;null&#x60;; consumers must not interpret that as zero.  Account-scoped: the bearer must be a buyer-scoped API key, an OAuth access token carrying &#x60;balance&#x60;, or a claimed &#x60;wbt_*&#x60; bearer.

### Example

```ts
import {
  Configuration,
  BalanceApi,
} from '@weft-labs/sdk';
import type { GetBalanceRequest } from '@weft-labs/sdk';

async function example() {
  console.log("🚀 Testing @weft-labs/sdk SDK...");
  const config = new Configuration({
    // Configure HTTP bearer authorization: bearerAuth
    accessToken: "YOUR BEARER TOKEN",
  });
  const api = new BalanceApi(config);

  try {
    const data = await api.getBalance();
    console.log(data);
  } catch (error) {
    console.error(error);
  }
}

// Run the test
example().catch(console.error);
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**BalanceResponse**](BalanceResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Wallet + policy + spend snapshot |  -  |
| **401** | Unauthorized — missing or non-buyer-scoped API key |  -  |
| **403** | The OAuth access token authenticated but lacks the &#x60;balance&#x60; scope (RFC 6750 &#x60;insufficient_scope&#x60;). Carries a &#x60;WWW-Authenticate: Bearer error&#x3D;\&quot;insufficient_scope\&quot;, scope&#x3D;\&quot;balance\&quot;&#x60; header. &#x60;wk_&#x60; API keys are unscoped and never see this.  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)
