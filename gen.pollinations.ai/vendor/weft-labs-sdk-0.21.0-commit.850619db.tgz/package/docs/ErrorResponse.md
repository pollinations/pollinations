
# ErrorResponse

Standard error envelope returned by all `/api/v1` endpoints except `/search` and `/fetch` (which use bespoke envelopes carrying additional context). `error.code` is stable across releases and safe to branch on; `error.message` is human-readable and may change.

## Properties

Name | Type
------------ | -------------
`error` | Error

## Example

```typescript
import type { ErrorResponse } from '@weft-labs/sdk'

// TODO: Update the object below with actual values
const example = {
  "error": null,
} satisfies ErrorResponse

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as ErrorResponse
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)
