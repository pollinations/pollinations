
# SearchCuratedCallability


## Properties

Name | Type
------------ | -------------
`state` | string
`missing` | Array&lt;string&gt;

## Example

```typescript
import type { SearchCuratedCallability } from '@weft-labs/sdk'

// TODO: Update the object below with actual values
const example = {
  "state": null,
  "missing": null,
} satisfies SearchCuratedCallability

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as SearchCuratedCallability
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)
